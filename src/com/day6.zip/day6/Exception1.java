package com.day6;

public class Exception1 {
	public static void main(String[] args)
	{
		ExceptionDemo exceptionDemo = new ExceptionDemo();
		exceptionDemo.printException();
	}
}
